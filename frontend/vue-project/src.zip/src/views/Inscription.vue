<script setup>

import InscriptionForm from '/src/components/InscriptionForm.vue';
import Header from '/src/components/Header.vue';



</script>

<template>

    <Header/>
    <div class="container pt-3">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <InscriptionForm/>
            </div>
            <div class="col-2"></div>
        </div>
    </div>
        
    
  
</template>

<style >

</style>

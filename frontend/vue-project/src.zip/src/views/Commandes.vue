<script setup>


import Header from '/src/components/Header.vue';
import CommandesComp from '/src/components/CommandesComp.vue';




</script>

<template>
    <Header/>
    <h3 class="text-white text-center">Commandes</h3>
    <CommandesComp/>
    
  
</template>

<style >

</style>

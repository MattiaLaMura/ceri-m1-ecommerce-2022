<script setup>

import AlbumList from '/src/components/AlbumList.vue';
import Header from '/src/components/Header.vue';
import Carousel from '/src/components/Carousel.vue';


</script>

<template>

    <Header/>
    <Carousel/>
    <h2 class="text-white text-center">Liste des albums</h2>
    <AlbumList/>
  
</template>

<style >

</style>

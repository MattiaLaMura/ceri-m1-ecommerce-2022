<script setup>
import Header from '/src/components/Header.vue';
import AlbumDetails from '/src/components/AlbumDetails.vue';
import PanierComp from '/src/components/PanierComp.vue';
</script>

<template>
    <Header/>
    <h3 class="text-white text-center">Panier</h3>
    <PanierComp/>
</template>

<style >

</style>

<script setup>

import AlbumList from '/src/components/AlbumList.vue';
import HeaderBackoffice from '/src/components/backoffice/HeaderBackoffice.vue';
import BackofficeAlbumList from '/src/components/backoffice/BackofficeAlbumList.vue';

</script>

<template>

    <HeaderBackoffice/>
    <BackofficeAlbumList/>
  
</template>

<style >

</style>
